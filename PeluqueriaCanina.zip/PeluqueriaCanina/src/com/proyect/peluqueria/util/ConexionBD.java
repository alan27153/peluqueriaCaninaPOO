package com.proyect.peluqueria.util;

import com.proyect.peluqueria.env.Env;
import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

public class ConexionBD {
    Connection connect = null;
    
    //Conexion con bases de datos remota
    private final String DB="b7h8b6mwgfihkazi2gtn";
    private final String USER=Env.user;
    private final String PASS=Env.pass;
    private final String DRIVER="com.mysql.cj.jdbc.Driver";
    private final String PORT="3306";
    private final String HOST="b7h8b6mwgfihkazi2gtn-mysql.services.clever-cloud.com";
    private final String URL="jdbc:mysql://"+HOST+":"+PORT+"/"+DB;
   
    //Conexion con base de datos local XAMPP. Utilizar estos valores en caso de què la conexiòn remota falle. 
    //    private final String URL = "jdbc:mysql://localhost:3306/test";
    //    private final String PASS = "";
    //    private final String USER = "root";

    public Connection establecerConexion(){
        try{
           Class.forName(DRIVER);
           connect = (Connection) DriverManager.getConnection(URL,USER,PASS);
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,"Contraseña o usuario incorrectos");
            return null;        
        }
        return connect;
    }
}
