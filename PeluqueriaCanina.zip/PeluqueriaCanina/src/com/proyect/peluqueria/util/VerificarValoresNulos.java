package com.proyect.peluqueria.util;

public class VerificarValoresNulos {
    public static boolean verificar(String nomDueño,String telefono,String nomMascota,String raza,String sexo,String edad,String citaInicioH,String citaInicioM,String citaFinH,String citaFinM,String fecha){
        if(nomDueño.equals("")||telefono.equals("")||nomMascota.equals("")||raza.equals("")||sexo.equals("")||edad.equals("")||citaInicioH.equals("")||citaInicioM.equals("")||citaFinH.equals("")||citaFinM.equals("")||fecha.equals("")){
            return true; //Algun dato esta vacio
        }else{
            return false; //Ningun dato esta vacio
        }
    }
}