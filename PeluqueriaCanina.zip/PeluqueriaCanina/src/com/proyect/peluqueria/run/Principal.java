package com.proyect.peluqueria.run;

import com.proyect.peluqueria.controllers.EliminarController;
import com.proyect.peluqueria.controllers.InsertController;
import com.proyect.peluqueria.controllers.LoginController;
import com.proyect.peluqueria.controllers.ModificarController;
import com.proyect.peluqueria.controllers.ObtenerTodosController;
import com.proyect.peluqueria.controllers.ObtenerUnoController;
import com.proyect.peluqueria.dao.impl.DaoDueñoImpl;
import com.proyect.peluqueria.env.Env;
import com.proyect.peluqueria.view.HomePageFrame;
import com.proyect.peluqueria.view.LoginFrame;
import javax.swing.JOptionPane;

public class Principal {     
//CREATE TABLE Dueño (
//  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
//  nombreDueño VARCHAR(50), 
//  telefono VARCHAR(50),
//  nombreMascota VARCHAR(50),
//  raza VARCHAR(50),
//  sexo VARCHAR(50),
//  edad VARCHAR(50),
//  citaInicio VARCHAR(50),
//  citaFin VARCHAR(50),
//  fecha VARCHAR(50)
//); 

//INSERT INTO Dueño (nombreDueño, telefono,
// nombreMascota, raza, sexo, edad,
// citaInicio, citaFin, fecha)
//VALUES
//  ('Juan Perez', '555-1234', 'Fido', 'Labrador',
//  'Macho', '3 años', '10:00:00', '11:00:00', '2023-12-05'),
//  ('Maria Garcia', '555-5678', 'Luna', 'Poodle',
//  'Hembra', '2 años', '14:00:00', '5:00:00', '2023-12-06'),
//   ('Pedro Rodriguez', '555-9012', 'Rocky', 'Bulldog',
//   'Macho', '5 años', '16:00:00', '17:00:00', '2023-12-07');

//            u7bjmyal6oeqbn6s
//            vZmTOrlgc7IowU2AIKJo
    
        public static LoginFrame loginFrame = new LoginFrame();
        public static HomePageFrame homePage = new HomePageFrame();
        public static Env env = new Env();
        public static DaoDueñoImpl daoDueñoImpl = new DaoDueñoImpl();
        
    public static void main(String[] args) {
        try{
        LoginController lc = new LoginController(loginFrame,env);
        lc.iniciar();
               
        InsertController ic = new InsertController(homePage,daoDueñoImpl);
        ic.iniciar();

        ObtenerUnoController ouc = new ObtenerUnoController(homePage,daoDueñoImpl);
        ouc.iniciar();

        ModificarController mc = new ModificarController(homePage,daoDueñoImpl);
        mc.iniciar();

        EliminarController ec = new EliminarController(homePage,daoDueñoImpl);
        ec.iniciar();
        
        ObtenerTodosController otc = new ObtenerTodosController(homePage,daoDueñoImpl);
        otc.iniciar();
        
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"Ocurrio un error en el programa");            
        }
    }
}
