package com.proyect.peluqueria.dao;

import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;

public interface DaoDueño {
    void insertar(String nombreDueño, String telefono, String nombreMascota, String raza, String sexo, String edad, String citaInicioH, String citaInicioM, String citaFinH, String citaFinM, String fecha);
    ResultSet obtenerUno(String citaInicioH, String citaInicioM, String fecha);
    DefaultTableModel obtenerTodos();
    void modificar(String nombreDueño, String telefono, String nombreMascota, String raza, String sexo, String edad, String citaInicioH, String citaInicioM, String citaFinH, String citaFinM, String fecha);
    void eliminar(String citaInicioH, String citaInicioM, String fecha);
    
//    void insertar(String nombres, String telefono, String nomMascota);
//    void obtenerUno(int id);
//    void obtenerTodos();
//    void modificar(int id);
//    void eliminar(int id); 
}
