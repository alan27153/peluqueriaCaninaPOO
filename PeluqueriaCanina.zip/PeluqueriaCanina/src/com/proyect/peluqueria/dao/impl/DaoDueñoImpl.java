package com.proyect.peluqueria.dao.impl;

import com.proyect.peluqueria.dao.DaoDueño;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import com.proyect.peluqueria.util.ConexionBD;
import java.sql.Connection;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class DaoDueñoImpl implements DaoDueño{
    
    @Override
    public void insertar(String nombreDueño, String telefono, String nombreMascota, String raza, String sexo, String edad, String citaInicioH, String citaInicioM, String citaFinH, String citaFinM, String fecha) {
        ConexionBD objetoConexion = new ConexionBD();
        String consulta = "INSERT INTO Dueño (nombreDueño, telefono, nombreMascota, raza, sexo, edad, citaInicio, citaFin, fecha) VALUES (?,?,?,?,?,?,?,?,?);";

        try{
            CallableStatement cs = objetoConexion.establecerConexion().prepareCall(consulta);
            
            StringBuilder citaInicioSB = new StringBuilder();
            citaInicioSB.append(citaInicioH);
            citaInicioSB.append(":");
            citaInicioSB.append(citaInicioM);
            citaInicioSB.append(":00 ");
            String citaInicio2 = citaInicioSB.toString();
            
            StringBuilder citaFinSB = new StringBuilder();
            citaFinSB.append(citaFinH);
            citaFinSB.append(":");
            citaFinSB.append(citaFinM);
            citaFinSB.append(":00 ");
            String citaFin2 = citaFinSB.toString();
                     
            cs.setString(1, nombreDueño);
            cs.setString(2, telefono);
            cs.setString(3, nombreMascota);
            cs.setString(4, raza);
            cs.setString(5, sexo);
            cs.setString(6, edad);
            cs.setString(7, citaInicio2);
            cs.setString(8, citaFin2);
            cs.setString(9, fecha);

            cs.execute();
            JOptionPane.showMessageDialog(null,"Cita registrada correctamente");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Ocurrio un error al crear la cita");
        }
    }
    
    @Override
    public ResultSet obtenerUno(String citaInicioH, String citaInicioM, String fecha) {
        String consulta = "SELECT * FROM Dueño WHERE citaInicio = ? AND fecha = ?";
        ResultSet rs = null;
        
        StringBuilder sb = new StringBuilder();
        sb.append(citaInicioH);
        sb.append(":");
        sb.append(citaInicioM);
        sb.append(":00");
        String citaInicio = sb.toString();
        
        try{
        ConexionBD objetoConexion = new ConexionBD();        
        Connection con = objetoConexion.establecerConexion();
        PreparedStatement pst = con.prepareStatement(consulta);
        pst.setString(1,citaInicio);
        pst.setString(2,fecha);
        rs = pst.executeQuery();
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"La cita a buscar no esta escrita de forma correcta");        
        }
        return rs;
    }
    
    @Override
    public DefaultTableModel obtenerTodos() {
        String consulta = "SELECT * FROM Dueño";
        
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("ID");
        modelo.addColumn("Dueño");
        modelo.addColumn("Telefono");
        modelo.addColumn("Mascota");
        modelo.addColumn("Raza");
        modelo.addColumn("Sexo");
        modelo.addColumn("Edad");
        modelo.addColumn("CitaInicio");
        modelo.addColumn("CitaFin");
        modelo.addColumn("Fecha");
        
        try {
        ConexionBD objetoConexion = new ConexionBD();        
        Statement st = objetoConexion.establecerConexion().createStatement();
        ResultSet rs = st.executeQuery(consulta);              
            while(rs.next()){
                String[] datos = new String[10];
                datos[0]=rs.getString(1);
                datos[1]=rs.getString(2);
                datos[2]=rs.getString(3);
                datos[3]=rs.getString(4);
                datos[4]=rs.getString(5);
                datos[5]=rs.getString(6);
                datos[6]=rs.getString(7);
                datos[7]=rs.getString(8);
                datos[8]=rs.getString(9);
                datos[9]=rs.getString(10);
                modelo.addRow(datos);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null,"Ocurrio un error al insertar todos los datos en la tabla");                    
        }
        return modelo;
    }

    @Override
    public void modificar(String nombreDueño, String telefono, String nombreMascota, String raza, String sexo, String edad, String citaInicioH, String citaInicioM, String citaFinH, String citaFinM, String fecha) {          
        String consulta = "UPDATE Dueño SET nombreDueño = ?, telefono = ?, nombreMascota = ?, raza = ?, sexo = ?, edad = ?, citaInicio = ?, citaFin = ?, fecha = ? WHERE citaInicio = ? AND fecha = ?;";
        
            StringBuilder citaInicioSB = new StringBuilder();
            citaInicioSB.append(citaInicioH);
            citaInicioSB.append(":");
            citaInicioSB.append(citaInicioM);
            citaInicioSB.append(":00");
            String citaInicio2 = citaInicioSB.toString();
            
            StringBuilder citaFinSB = new StringBuilder();
            citaFinSB.append(citaFinH);
            citaFinSB.append(":");
            citaFinSB.append(citaFinM);
            citaFinSB.append(":00");
            String citaFin2 = citaFinSB.toString();
            

        try{
            ConexionBD objetoConexion = new ConexionBD();
            Connection con = objetoConexion.establecerConexion();
            PreparedStatement ps = con.prepareStatement(consulta);
            ps.setString(1, nombreDueño);
            ps.setString(2, telefono);
            ps.setString(3, nombreMascota);
            ps.setString(4, raza);
            ps.setString(5, sexo);
            ps.setString(6, edad);
            ps.setString(7, citaInicio2);
            ps.setString(8, citaFin2);
            ps.setString(9, fecha);
            ps.setString(10, citaInicio2);
            ps.setString(11, fecha);
            
            int cont = ps.executeUpdate();
            System.out.println(cont==0);
            if(cont == 0){
                JOptionPane.showMessageDialog(null,"Se actualizo correctamente");                                   
            }
        } catch (Exception e) {
                JOptionPane.showMessageDialog(null,"No se pudo actualizar la cita");                                   
        }
    }

    @Override
    public void eliminar(String citaInicioH, String citaInicioM, String fecha) {
        ConexionBD objetoConexion = new ConexionBD();
        String consulta = "DELETE FROM Dueño WHERE citaInicio = ? AND fecha = ?";

            StringBuilder citaInicioSB = new StringBuilder();
            citaInicioSB.append(citaInicioH);
            citaInicioSB.append(":");
            citaInicioSB.append(citaInicioM);
            citaInicioSB.append(":00");
            String citaInicio2 = citaInicioSB.toString();
            System.out.println(citaInicio2);
            System.out.println(fecha);            
//        try{
//           PreparedStatement pst = conexion.prepareStatement(consulta);
//           pst.setString(1,citaInicio2);
//           pst.setString(1,fecha);
//           ResultSet rs = pst.executeQuery();
//            System.out.println(citaInicio2);
//            System.out.println(fecha);
//            JOptionPane.showMessageDialog(null,"La cita se elimino correctamente");                                   
//        }catch(Exception e){           
//            JOptionPane.showMessageDialog(null,"La cita a eliminar no existe");                    
//        }


        try (Connection c = objetoConexion.establecerConexion()) {
            PreparedStatement pst = c.prepareStatement(consulta);
            pst.setString(1,citaInicio2);
            pst.setString(2,fecha);
            int cont = pst.executeUpdate();
            if(cont == 0){
                    JOptionPane.showMessageDialog(null,"La cita a eliminar no existe");                  
            }else{
                    JOptionPane.showMessageDialog(null,"La cita se elimino correctamente");                                 
            }
        } catch (Exception e) {
            System.out.println("La cita a eliminar no existe");
        }
        
//        try{
//           PreparedStatement pst = conexion.prepareStatement(consulta);
//           pst.setString(1,citaInicio2);
//           pst.setString(1,fecha);
//           pst.executeUpdate();
//            System.out.println(citaInicio2);
//                        System.out.println(fecha);
//            JOptionPane.showMessageDialog(null,"La cita se elimino correctamente");                                   
//        }catch(Exception e){           
//            JOptionPane.showMessageDialog(null,"La cita a eliminar no existe");                    
//        }
    }   
}
