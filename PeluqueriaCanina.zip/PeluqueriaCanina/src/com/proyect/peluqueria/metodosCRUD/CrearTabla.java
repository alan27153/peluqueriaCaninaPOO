package com.proyect.peluqueria.metodosCRUD;

import com.proyect.peluqueria.util.ConexionBD;
import java.sql.Connection;

public class CrearTabla {
    
//    private ConexionBD conexion = new ConexionBD();
//
//    private void crearTabla(String nomTabla){
//        try{    
//        Connection connect = conexion.establecerConexion();
//        String cadenaInsercion = "create table "+nomTabla;
//        
//    
//        }
}
