package com.proyect.peluqueria.metodosCRUD;

import com.proyect.peluqueria.util.ConexionBD;
import java.sql.Connection;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class InsertarRegistro{
    private ConexionBD conexion = new ConexionBD();
    public int insertarRegistro(String nomTabla, Object[] datos){
        int filasAfectadas=0;
        try{    
        Connection connect = conexion.establecerConexion();
        String cadenaInsercion = "inser into "+nomTabla+" values ("+"'"+datos[0]+"'";
    
        for(int i=1; i<=datos.length;i++){
            if(i<datos.length){
                cadenaInsercion+=",'"+datos[i]+"'";
            }else
                cadenaInsercion+="}";
        }
        
        JOptionPane.showMessageDialog(null,cadenaInsercion);
        Statement sentenciaInsert = connect.createStatement();
        filasAfectadas = sentenciaInsert.executeUpdate(cadenaInsercion);
            System.out.println("Registro alamcenado correctamente en la tabla"+nomTabla);
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null,ex);
        }
        return filasAfectadas;
    }
    
}
