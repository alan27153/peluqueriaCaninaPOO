package com.proyect.peluqueria.env;

public class Env {
    public static String user;
    public static String pass;    
}
