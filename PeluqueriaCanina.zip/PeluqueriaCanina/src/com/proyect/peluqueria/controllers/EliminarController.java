package com.proyect.peluqueria.controllers;

import com.proyect.peluqueria.dao.impl.DaoDueñoImpl;
import com.proyect.peluqueria.view.HomePageFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;


public class EliminarController implements ActionListener {
    public static HomePageFrame homePageFrame;
    public static DaoDueñoImpl daoDueñoImpl;

    public EliminarController(HomePageFrame homePageFrame,DaoDueñoImpl daoDueñoImpl) {
        this.homePageFrame = homePageFrame;
        this.daoDueñoImpl = daoDueñoImpl;
        this.homePageFrame.jButtonEliminar.addActionListener(this);
    }

    public void iniciar(){
    }

    @Override
    public void actionPerformed(ActionEvent e) {   
        String citaInicioH = homePageFrame.jTextFieldInicioH.getText();
        String citaInicioM = homePageFrame.jTextFieldInicioM.getText();
        String fecha = homePageFrame.jTextFieldFecha.getText();
        if(homePageFrame.jTextFieldInicioH.getText().isEmpty()||homePageFrame.jTextFieldInicioM.getText().isEmpty()||homePageFrame.jTextFieldFecha.getText().isEmpty()){
            JOptionPane.showMessageDialog(null,"Para eliminar una cita se necesita conocer Cita inicio y Fecha");
        }else{         
              daoDueñoImpl.eliminar(citaInicioH, citaInicioM, fecha);          
                            
        }        
    }     
}
