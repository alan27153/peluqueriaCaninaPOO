package com.proyect.peluqueria.controllers;

import static com.proyect.peluqueria.controllers.ObtenerTodosController.homePageFrame;
import com.proyect.peluqueria.dao.impl.DaoDueñoImpl;
import com.proyect.peluqueria.view.HomePageFrame;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class ObtenerUnoController implements ActionListener {
    public static HomePageFrame homePageFrame;
    public static DaoDueñoImpl daoDueñoImpl;

    public ObtenerUnoController(HomePageFrame homePageFrame,DaoDueñoImpl daoDueñoImpl) {
        this.homePageFrame = homePageFrame;
        this.daoDueñoImpl = daoDueñoImpl;
        this.homePageFrame.jButtonObtener.addActionListener(this);
    }

    public void iniciar(){
    }

    @Override
    public void actionPerformed(ActionEvent e) {   
        String citaInicioH = homePageFrame.jTextFieldInicioH.getText();
        String citaInicioM = homePageFrame.jTextFieldInicioM.getText();
        String fecha = homePageFrame.jTextFieldFecha.getText();
        if(homePageFrame.jTextFieldInicioH.getText().isEmpty()||homePageFrame.jTextFieldInicioM.getText().isEmpty()||homePageFrame.jTextFieldFecha.getText().isEmpty()){
            JOptionPane.showMessageDialog(null,"Para obtener la cita a buscar se necesita saber la Cita inicio y Fecha");
        }else{
              ResultSet rs = daoDueñoImpl.obtenerUno(citaInicioH, citaInicioM, fecha);          
            try {
              if(rs.next()){
                DefaultTableModel modelo = new DefaultTableModel();
                TableRowSorter<TableModel> ordenarTabla = new TableRowSorter<TableModel>(modelo);
                homePageFrame.jTableDatos.setRowSorter(ordenarTabla);
                modelo.addColumn("ID");
                modelo.addColumn("Dueño");
                modelo.addColumn("Telefono");
                modelo.addColumn("Mascota");
                modelo.addColumn("Raza");
                modelo.addColumn("Sexo");
                modelo.addColumn("Edad");
                modelo.addColumn("CitaInicio");
                modelo.addColumn("CitaFin");
                modelo.addColumn("Fecha");
                String[] datos = new String[10]; 
                datos[0]=rs.getString(1);
                datos[1]=rs.getString(2);
                datos[2]=rs.getString(3);
                datos[3]=rs.getString(4);
                datos[4]=rs.getString(5);
                datos[5]=rs.getString(6);
                datos[6]=rs.getString(7);
                datos[7]=rs.getString(8);
                datos[8]=rs.getString(9);
                datos[9]=rs.getString(10);
                modelo.addRow(datos);
            homePageFrame.jTableDatos.setModel(modelo);
            }else{
            JOptionPane.showMessageDialog(null,"No se encontro la cita en la base de datos");                                      
              }                        
            } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Ocurrio un error al buscar la cita");                    
            }               
        }        
    }     
}
