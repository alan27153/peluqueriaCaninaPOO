package com.proyect.peluqueria.controllers;

import static com.proyect.peluqueria.controllers.InsertController.daoDueñoImpl;
import static com.proyect.peluqueria.controllers.InsertController.homePageFrame;
import com.proyect.peluqueria.dao.impl.DaoDueñoImpl;
import com.proyect.peluqueria.view.HomePageFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class ModificarController implements ActionListener {
    public static HomePageFrame homePageFrame;
    public static DaoDueñoImpl daoDueñoImpl;

    public ModificarController(HomePageFrame homePageFrame,DaoDueñoImpl daoDueñoImpl) {
        this.homePageFrame = homePageFrame;
        this.daoDueñoImpl = daoDueñoImpl;
        this.homePageFrame.jButtonModificar.addActionListener(this);
    }

    public void iniciar(){
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String nombreDueño = homePageFrame.jTextFieldNomDueño.getText();
        String telefono = homePageFrame.jTextFieldTelefono.getText();
        String nombreMascota = homePageFrame.jTextFieldNomMascota.getText();
        String raza = homePageFrame.jTextFieldRaza.getText();
        String sexo = homePageFrame.jTextFieldSexo.getText();
        String edad = homePageFrame.jTextFieldEdad.getText();
        String citaInicioH = homePageFrame.jTextFieldInicioH.getText();
        String citaInicioM = homePageFrame.jTextFieldInicioM.getText();
        String citaFinH = homePageFrame.jTextFieldFinH.getText();
        String citaFinM = homePageFrame.jTextFieldFinM.getText();
        String fecha = homePageFrame.jTextFieldFecha.getText();
        if(homePageFrame.jTextFieldNomDueño.getText().isEmpty()||homePageFrame.jTextFieldTelefono.getText().isEmpty()||homePageFrame.jTextFieldNomMascota.getText().isEmpty()||homePageFrame.jTextFieldRaza.getText().isEmpty()||homePageFrame.jTextFieldSexo.getText().isEmpty()||homePageFrame.jTextFieldEdad.getText().isEmpty()||homePageFrame.jTextFieldInicioH.getText().isEmpty()||homePageFrame.jTextFieldInicioM.getText().isEmpty()||homePageFrame.jTextFieldFinH.getText().isEmpty()||homePageFrame.jTextFieldFinM.getText().isEmpty()||homePageFrame.jTextFieldFecha.getText().isEmpty()){
            JOptionPane.showMessageDialog(null,"Faltan llenar datos");
        }else{          
              daoDueñoImpl.modificar(nombreDueño, telefono, nombreMascota, raza, sexo, edad, citaInicioH, citaInicioM, citaFinH, citaFinM, fecha);
        }     
    }     
}
