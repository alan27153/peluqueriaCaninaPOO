package com.proyect.peluqueria.controllers;

import com.proyect.peluqueria.env.Env;
import com.proyect.peluqueria.run.Principal;
import com.proyect.peluqueria.util.ConexionBD;
import com.proyect.peluqueria.view.LoginFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class LoginController implements ActionListener{
    public static LoginFrame loginFrame;
    public static Env env;

    
    public LoginController(LoginFrame loginFrame,Env env) {
        this.loginFrame = loginFrame;
        this.env = env;
        this.loginFrame.btnEntry.addActionListener(this);
    }
    
    public void iniciar(){
        loginFrame.setVisible(true);
        loginFrame.setLocationRelativeTo(null);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        env.user = loginFrame.jTextUser.getText();
        env.pass = loginFrame.jTextPass.getText();
        ConexionBD conexion = new ConexionBD();
        if(conexion.establecerConexion()!=null){
            JOptionPane.showMessageDialog(null,"Logeado correctamente");            
            loginFrame.dispose();
            Principal.homePage.setVisible(true);
            Principal.homePage.setLocationRelativeTo(null);
        }
    }   
}
