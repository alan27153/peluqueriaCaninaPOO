package com.proyect.peluqueria.controllers;

import com.proyect.peluqueria.dao.impl.DaoDueñoImpl;
import com.proyect.peluqueria.run.Principal;
import com.proyect.peluqueria.util.ConexionBD;
import com.proyect.peluqueria.view.HomePageFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import java.sql.ResultSet;


public class InsertController implements ActionListener {
    public static HomePageFrame homePageFrame;
    public static DaoDueñoImpl daoDueñoImpl;

    public InsertController(HomePageFrame homePageFrame,DaoDueñoImpl daoDueñoImpl) {
        this.homePageFrame = homePageFrame;
        this.daoDueñoImpl = daoDueñoImpl;
        this.homePageFrame.jButtonNuevoCliente.addActionListener(this);
    }

    public void iniciar(){
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String nombreDueño = homePageFrame.jTextFieldNomDueño.getText();
        String telefono = homePageFrame.jTextFieldTelefono.getText();
        String nombreMascota = homePageFrame.jTextFieldNomMascota.getText();
        String raza = homePageFrame.jTextFieldRaza.getText();
        String sexo = homePageFrame.jTextFieldSexo.getText();
        String edad = homePageFrame.jTextFieldEdad.getText();
        String citaInicioH = homePageFrame.jTextFieldInicioH.getText();
        String citaInicioM = homePageFrame.jTextFieldInicioM.getText();
        String citaFinH = homePageFrame.jTextFieldFinH.getText();
        String citaFinM = homePageFrame.jTextFieldFinM.getText();
        String fecha = homePageFrame.jTextFieldFecha.getText();
        if(homePageFrame.jTextFieldNomDueño.getText().isEmpty()||homePageFrame.jTextFieldTelefono.getText().isEmpty()||homePageFrame.jTextFieldNomMascota.getText().isEmpty()||homePageFrame.jTextFieldRaza.getText().isEmpty()||homePageFrame.jTextFieldSexo.getText().isEmpty()||homePageFrame.jTextFieldEdad.getText().isEmpty()||homePageFrame.jTextFieldInicioH.getText().isEmpty()||homePageFrame.jTextFieldInicioM.getText().isEmpty()||homePageFrame.jTextFieldFinH.getText().isEmpty()||homePageFrame.jTextFieldFinM.getText().isEmpty()||homePageFrame.jTextFieldFecha.getText().isEmpty()){
            JOptionPane.showMessageDialog(null,"Falta llenar datos");
        }else{          
            daoDueñoImpl.insertar(nombreDueño, telefono, nombreMascota, raza, sexo, edad, citaInicioH, citaInicioM, citaFinH, citaFinM, fecha);
            homePageFrame.jTextFieldNomDueño.setText("");
            homePageFrame.jTextFieldTelefono.setText("");
            homePageFrame.jTextFieldNomMascota.setText("");
            homePageFrame.jTextFieldRaza.setText("");
            homePageFrame.jTextFieldSexo.setText("");
            homePageFrame.jTextFieldEdad.setText("");
            homePageFrame.jTextFieldInicioH.setText("");
            homePageFrame.jTextFieldInicioM.setText("");
            homePageFrame.jTextFieldFinH.setText("");
            homePageFrame.jTextFieldFinM.setText("");
            homePageFrame.jTextFieldFecha.setText("");
        }
        
    }     
}
