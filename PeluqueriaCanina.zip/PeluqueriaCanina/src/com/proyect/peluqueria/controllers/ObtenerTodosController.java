package com.proyect.peluqueria.controllers;

import com.proyect.peluqueria.dao.impl.DaoDueñoImpl;
import com.proyect.peluqueria.view.HomePageFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class ObtenerTodosController implements ActionListener {
    public static HomePageFrame homePageFrame;
    public static DaoDueñoImpl daoDueñoImpl;

    public ObtenerTodosController(HomePageFrame homePageFrame,DaoDueñoImpl daoDueñoImpl) {
        this.homePageFrame = homePageFrame;
        this.daoDueñoImpl = daoDueñoImpl;
        this.homePageFrame.jButtonVerTodo.addActionListener(this);
    }

    public void iniciar(){
    }

    @Override
    public void actionPerformed(ActionEvent e) {      
//        DefaultTableModel modelo = new DefaultTableModel();
//        TableRowSorter<TableModel> ordenarTabla = new TableRowSorter<TableModel>(modelo);
//        homePageFrame.jTableDatos.setRowSorter(ordenarTabla);
          homePageFrame.jTableDatos.setModel(daoDueñoImpl.obtenerTodos());        
//        try {
//            while(rs.next()){
//                datos[0]=rs.getString(1);
//                datos[1]=rs.getString(2);
//                datos[2]=rs.getString(3);
//                datos[3]=rs.getString(4);
//                datos[4]=rs.getString(5);
//                datos[5]=rs.getString(6);
//                datos[6]=rs.getString(7);
//                datos[7]=rs.getString(8);
//                datos[8]=rs.getString(9);
//                datos[9]=rs.getString(10);
//                modelo.addRow(datos);
//            }
//            homePageFrame.jTableDatos.setModel(modelo);            
//        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(null,"Ocurrio un error al insertar todos los datos en la tabla");                    
//        }
    }     
}

