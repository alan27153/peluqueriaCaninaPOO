package com.proyect.peluqueria.entity;

public class Dueño{
    private String nombreDueño;
    private String telefono;
    private String nombreMascota;
    private String raza;
    private String sexo;
    private String edad;
    private String citaInicio;
    private String citaFin;
    private String fecha;

    public String getNombreDueño() {
        return nombreDueño;
    }

    public void setNombreDueño(String nombreDueño) {
        this.nombreDueño = nombreDueño;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getNombreMascota() {
        return nombreMascota;
    }

    public void setNombreMascota(String nombreMascota) {
        this.nombreMascota = nombreMascota;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getEdad() {
        return edad;
    }

    public void setEdad(String edad) {
        this.edad = edad;
    }

    public String getCitaInicio() {
        return citaInicio;
    }

    public void setCitaInicio(String citaInicio) {
        this.citaInicio = citaInicio;
    }

    public String getCitaFin() {
        return citaFin;
    }

    public void setCitaFin(String citaFin) {
        this.citaFin = citaFin;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    
}
